- due to large `.ipynb` file, attaching snapshot along with colab file link.
> [colab link](https://colab.research.google.com/drive/1rH3-aOl86KKmev45oaiLrKUCP5NePdk3?usp=sharing)

|Snapshot of Code|
|---|
|![](./19BCE245-DIPA-Practical10.png)|